# Publishing Convergence on Cloudflare Pages

This gets your app live on the internet, free, with no credits and no bandwidth
caps, and set up so you can keep improving it without ever paying.

You will do this once. After that, every change you make redeploys automatically.

---

## What you are setting up

- **GitHub** holds your code and saves every version (so you can undo anything).
- **Cloudflare Pages** takes that code and serves it to the world as a real website.

Both are free. Neither charges for traffic. This is the setup that will not
punish you for launching to a TikTok audience.

---

## Part 1: Put the code on GitHub (about 10 minutes)

1. Go to **github.com** and make a free account if you don't have one.
2. Click the **+** in the top right, then **New repository**.
3. Name it `convergence`. Leave it **Public** (Cloudflare's free tier works with
   public repos, and this keeps everything free). Click **Create repository**.
4. On the next page, click **uploading an existing file** (it's a small link in
   the middle of the page).
5. Drag in **every file and folder** from this `convergence-deploy` folder:
   - `index.html`
   - `package.json`
   - `vite.config.js`
   - `tailwind.config.js`
   - `postcss.config.js`
   - the entire `src` folder (with `App.jsx`, `main.jsx`, `index.css` inside)
6. Scroll down, click **Commit changes**.

Your code now lives on GitHub. Every future edit is saved and reversible.

---

## Part 2: Connect Cloudflare Pages (about 5 minutes)

1. Go to **dash.cloudflare.com** and make a free account.
2. In the left menu, click **Workers & Pages**.
3. Click **Create**, then the **Pages** tab, then **Connect to Git**.
4. Authorize GitHub when it asks, then pick your `convergence` repository.
5. On the build settings screen, enter exactly these:
   - **Framework preset:** `Vite`
   - **Build command:** `npm run build`
   - **Build output directory:** `dist`
6. Click **Save and Deploy**.

Cloudflare builds your app (takes about a minute) and gives you a live URL like
`https://convergence.pages.dev`. That link is your published app. Open it on your
phone and your computer, it works on both.

---

## Part 3: Improving it over time

This is the part that matters for you. To change anything:

1. Edit the file on GitHub (click the file, click the pencil icon, make changes,
   commit), **or** re-upload a new `App.jsx` the same way you uploaded the first time.
2. Cloudflare notices the change and rebuilds automatically within a minute.
3. Refresh your live URL. The change is there.

No credits. No build-minute rationing. No surprise bills. Ever.

If a change ever breaks something, GitHub keeps every past version, you can roll
back from the repository's history.

---

## Optional: a custom domain

When you're ready to use your own domain (like `convergence.taiyotalks.com`)
instead of the `.pages.dev` link:

1. In your Cloudflare Pages project, go to **Custom domains**.
2. Click **Set up a custom domain** and follow the prompts.

Free SSL (the padlock in the browser) is included automatically.

---

## Connecting the Swiss Ephemeris backend later

When you're ready to turn on full precision (true Placidus houses, Chiron,
Lilith, Vertex, arcsecond accuracy), open `src/App.jsx`, find this line near the
top:

```
const PRECISION_BACKEND_URL = "";
```

Put your PythonAnywhere URL between the quotes, for example:

```
const PRECISION_BACKEND_URL = "https://yourusername.pythonanywhere.com";
```

Commit the change. The app upgrades itself to full precision the moment the
backend answers, and falls back to the built-in math if it's ever unreachable.
(The backend file is `convergence_precision_api.py`, in your outputs folder.)

---

## If something goes wrong

- **Build failed on Cloudflare:** double-check the three build settings in Part 2,
  step 5. The output directory must be `dist`, not anything else.
- **Page loads but looks unstyled:** the `postcss.config.js` and
  `tailwind.config.js` files didn't upload. Re-upload them to the repository root.
- **Blank page:** make sure the `src` folder uploaded with all three files inside.
